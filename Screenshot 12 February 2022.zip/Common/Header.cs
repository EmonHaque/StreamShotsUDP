﻿public class Header
{
    public long Tick { get; set; }
    public bool IsNewFrame { get; set; }
    public int SequenceNo { get; set; }
    public int Length { get; set; }

    public Header() {}
    public Header(long tick, bool isNewFrame, int sequenceNo, int length) {
        Tick = tick;
        IsNewFrame = isNewFrame;
        SequenceNo = sequenceNo;
        Length = length;
    }

    public byte[] Pack() {
        var array = new byte[17];
        Array.Copy(BitConverter.GetBytes(Tick), 0, array, 0, 8);
        Array.Copy(BitConverter.GetBytes(IsNewFrame), 0, array, 8, 1);
        Array.Copy(BitConverter.GetBytes(SequenceNo), 0, array, 9, 4);
        Array.Copy(BitConverter.GetBytes(Length), 0, array, 13, 4);
        return array;
    }
    public static Header Unpack(byte[] array) {
        var header = new Header();
        header.Tick = BitConverter.ToInt64(array, 0);
        header.IsNewFrame = BitConverter.ToBoolean(array, 8);
        header.SequenceNo = BitConverter.ToInt32(array, 9);
        header.Length = BitConverter.ToInt32(array, 13);
        return header;
    }
}

