﻿public class Constants
{
    public const string IP = "127.0.0.1";
    public const int PORT = 7777;
    public const int HEADER_SIZE = 8 + 1 + 4 + 4;
    public const int BUFFER_SIZE = HEADER_SIZE + 1024;
}

