﻿using System.Net;
using System.Windows.Media.Imaging;

class ClientWindow : Window
{
    Grid container;
    Image imageView;
    Socket socket;
    Thread receiver, presenter;
    ManualResetEventSlim mrSlim;
    MemoryStream currentFrame;

    public ClientWindow() {
        currentFrame = new MemoryStream();
        Width = 640;
        Height = 480;
        initializeWorker();
        receiver.Start();
        presenter.Start();
        imageView = new Image();
        container = new Grid() {
            Children = { imageView }
        };
        Content = container;
    }
    void initializeWorker() {
        socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        socket.Bind(new IPEndPoint(IPAddress.Parse(Constants.IP), Constants.PORT));
        receiver = new Thread(receive);
        mrSlim = new ManualResetEventSlim(false);
        presenter = new Thread(present);
    }
    void present() {
        while (true) {
            mrSlim.Wait();
            App.Current.Dispatcher.Invoke(() => {
                try {
                    var image = new BitmapImage();
                    image.BeginInit();
                    image.StreamSource = currentFrame;
                    image.EndInit();
                    imageView.Source = image;
                }
                catch { }
            });
            mrSlim.Reset();
        }   
    }
    void receive() {
        var stream = new MemoryStream();
        byte[] frame = new byte[0];
        byte[] ack = new byte[Constants.HEADER_SIZE];
        byte[] array = new byte[Constants.BUFFER_SIZE];
        EndPoint ep = new IPEndPoint(IPAddress.Any, 0);
        int read = 0;

        while (true) {          
            socket.ReceiveFrom(array, ref ep);
            Array.Copy(array, 0, ack, 0, Constants.HEADER_SIZE);
            socket.SendTo(ack, 0, Constants.HEADER_SIZE, SocketFlags.None, ep);
            var packet = Header.Unpack(ack);
            if(packet.IsNewFrame) {
                if(frame.Length > 0) {
                    currentFrame = new MemoryStream(frame);
                    mrSlim.Set();
                }
                read = 0;
                frame = new byte[packet.Length];              
            }
            else {
                Array.Copy(array, Constants.HEADER_SIZE, frame, read, packet.Length);
                read += packet.Length;
            }           
        }
    }
}

