﻿

class App : Application
{
    [STAThread]
    static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        App.Current.MainWindow = new ClientWindow();
        App.Current.MainWindow.Show();
    }
}

