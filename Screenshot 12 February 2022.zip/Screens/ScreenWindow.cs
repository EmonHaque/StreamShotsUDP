﻿using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Media.Imaging;

class ScreenWindow : Window
{
    Grid container;
    ComboBox screenCombo;
    Image imageView;
    System.Windows.Forms.Screen screen;
    int captureWidth, captureHeight;
    List<Monitor> monitors;
    ConcurrentQueue<MemoryStream> streams;
    Socket socket;
    Thread worker;
    byte[] buffer;
    EndPoint endPoint;

    public ScreenWindow() {
        Width = 800;
        Height = 640;
        screenCombo = new ComboBox();
        listScreens();
        Grid.SetRow(screenCombo, 1);
        imageView = new Image();
        container = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { imageView, screenCombo }
        };
        Content = container;
        screenCombo.SelectionChanged += onChange;
        screenCombo.SelectedIndex = 0;
        streams = new ConcurrentQueue<MemoryStream>();
        Task.Run(capture);
        initializeWorker();
        worker.Start();
    }
    void listScreens() {
        monitors = new List<Monitor>();
        var screens = System.Windows.Forms.Screen.AllScreens;
        foreach (var screen in screens) {
            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE));
            ScreenHelper.EnumDisplaySettings(screen.DeviceName, -1, ref dm);
            monitors.Add(new Monitor() {
                Name = screen.DeviceName.Substring(4),
                Width = dm.dmPelsWidth,
                Height = dm.dmPelsHeight
            });
        }
        screenCombo.ItemsSource = monitors;
    }
    void onChange(object sender, SelectionChangedEventArgs e) {
        if (screenCombo.SelectedIndex == -1) return;
        screen = System.Windows.Forms.Screen.AllScreens[screenCombo.SelectedIndex];
        var monitor = (Monitor)screenCombo.SelectedItem;
        captureWidth = monitor.Width;
        captureHeight = monitor.Height;
    }
    void initializeWorker() {
        socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        endPoint = new IPEndPoint(IPAddress.Parse(Constants.IP), Constants.PORT);
        worker = new Thread(startWork) { IsBackground = true };
    }
    void startWork() {
        buffer = new byte[Constants.BUFFER_SIZE];
        var ack = new byte[Constants.HEADER_SIZE];
        MemoryStream stream = null;

        while (true) {
            while (!streams.TryDequeue(out stream)) Thread.Sleep(10);

            int sequenceNo = 0;
            var array = stream.ToArray();
            int sent = 0;
            int lengthCopy = Constants.BUFFER_SIZE - Constants.HEADER_SIZE;
            int size = array.Length;
            int dataleft = size;

            var header = new Header(DateTime.Now.Ticks, true, sequenceNo, size);
            socket.SendTo(header.Pack(), SocketFlags.None, endPoint);           
            socket.Receive(ack, Constants.HEADER_SIZE, SocketFlags.None);
            acknowledge(header, ack, 3);

            while (sent < size) {
                sequenceNo++;
                header = new Header(DateTime.Now.Ticks, false, sequenceNo, lengthCopy);
                Array.Copy(header.Pack(), 0, buffer, 0, Constants.HEADER_SIZE);
                Array.Copy(array, sent, buffer, Constants.HEADER_SIZE, lengthCopy);

                socket.SendTo(buffer, SocketFlags.None, endPoint);
                socket.Receive(ack, Constants.HEADER_SIZE, SocketFlags.None);
                acknowledge(header, ack, 3);

                sent += lengthCopy;
                dataleft -= lengthCopy;
                if (dataleft < lengthCopy) {
                    if (dataleft > 0) lengthCopy = dataleft;
                }
            }
        }
    }
    void acknowledge(Header header, byte[] ack, int times) {
        var r = Header.Unpack(ack);
        for (int i = 0; i < times; i++) {
            if (r.SequenceNo != header.SequenceNo) {
                socket.SendTo(header.Pack(), SocketFlags.None, endPoint);
                socket.Receive(ack, Constants.HEADER_SIZE, SocketFlags.None);
                r = Header.Unpack(ack);
            }
            else break;
        }
    }
    void capture() {
        while (true) {
            int cursorX = 0;
            int cursorY = 0;

            var xScale = (double)captureWidth / screen.Bounds.Width;
            var yScale = (double)captureHeight / screen.Bounds.Height;

            var stream = new MemoryStream();
            var screenBMP = new System.Drawing.Bitmap(captureWidth, captureHeight);
            var cursorBMP = ScreenHelper.CaptureCursor(ref cursorX, ref cursorY, xScale > yScale ? xScale : yScale);
            var graphics = System.Drawing.Graphics.FromImage(screenBMP);

            graphics.CopyFromScreen(screen.Bounds.Left, 0, 0, 0, screenBMP.Size);
            var xFact = (double)(cursorX - screen.Bounds.Left) / screen.Bounds.Width * captureWidth;
            var yFact = (double)cursorY / screen.Bounds.Height * captureHeight;

            var cursorRect = new System.Drawing.Rectangle((int)xFact, (int)yFact, cursorBMP.Width, cursorBMP.Height);
            graphics.DrawImage(cursorBMP, cursorRect);
            graphics.Flush();

            screenBMP.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
            stream.Seek(0, SeekOrigin.Begin);

            graphics.Dispose();
            screenBMP.Dispose();
            cursorBMP.Dispose();
            streams.Enqueue(stream);

            App.Current.Dispatcher.Invoke(() => {
                try {
                    var image = new BitmapImage();
                    image.CacheOption = BitmapCacheOption.None;
                    image.BeginInit();
                    image.StreamSource = stream;
                    image.EndInit();
                    imageView.Source = image;
                }
                catch { }
            });
            Task.Delay(34);
        }
    }
}

